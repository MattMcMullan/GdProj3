import direct.directbase.DirectStart
from panda3d.core import Point2,Point3,Vec3,Vec4
from direct.gui.OnscreenText import OnscreenText
from direct.showbase.DirectObject import DirectObject
from direct.task.Task import Task
from panda3d.core import CollisionTraverser,CollisionNode
from panda3d.core import CollisionHandlerQueue,CollisionRay
from panda3d.core import Material,LRotationf,NodePath
from pandac.PandaModules import * #basic panda modules
from direct.showbase.DirectObject import DirectObject #for event handling
from direct.actor.Actor import Actor #for animated models
from direct.interval.IntervalGlobal import * #for compound intervals
import sys

def loadObject(tex, depth = 55, scale = 3, transparency = True):
    obj = loader.loadModel("Models/plane") #Every object uses the plane model
    obj.reparentTo(camera)          #Everything is parented to the camera so that it faces the screen
    obj.setPos(17.5, 55, -12.75) #Set initial position
    obj.setScale(scale)                 #Set initial scale
    obj.setBin("unsorted", 0)           #This tells Panda not to worry about the order this is drawn in. (it prevents an effect known as z-fighting)
    obj.setDepthTest(False)             #Tells panda not to check if something has already drawn in front of it (Everything in this game is at the same depth anyway)
    if transparency: obj.setTransparency(1) #All of our objects are trasnparent
    if tex:
        tex = loader.loadTexture(tex+".png") #Load the texture
        obj.setTexture(tex, 1)                           #Set the texture
    return obj

class Overlay(DirectObject):
    def __init__(self):

        #Tester Model
        camera.setPosHpr(0, -15, 7, 0, -15, 0)
        self.player = loader.loadModel("Models/player_temp")
        self.player.reparentTo(render)
        self.player.setPos(0,15,0)

        #HUD
        self.font = loader.loadFont("Fonts/Orbitron Light.otf")
        self.momPercent = 100
        self.wepCounter = 0
        self.wepAmmo = [5, 1, 0]
        self.percentDisplay = OnscreenText(text = "%s %s" % (self.momPercent, "%"), fg = (0,.75,1,1), pos = (-1.05, -.9), scale = .125, font = self.font)
        self.wepDisplay = OnscreenText(text = "%s" % (self.wepAmmo[self.wepCounter]), fg = (0,.75,1,1), pos = (1, -.9), scale = .125, font = self.font)
        self.wepIcon = loadObject("Sprites/weapon%s" %(self.wepCounter))

        #Define controls
        self.keys = {"swap-up": 0, "swap-down": 0, "m1": 0}
        self.accept("escape", sys.exit)
        self.accept("mouse1", self.setKey, ["m1", 1])
        self.accept("wheel_up", self.setKey, ["swap-up", 1])
        self.accept("wheel_down", self.setKey, ["swap-down", 1])

        self.gameTask = taskMgr.add(self.gameLoop, "gameLoop")
    
    def setKey(self, key, val): self.keys[key] = val
    
    def gameLoop(self, task):
        if base.mouseWatcherNode.hasMouse():
            mpos = base.mouseWatcherNode.getMouse()
        
        #Adds 10% each click
        if self.keys["m1"]:
            self.momPercent += 10
            self.percentDisplay.remove()
            self.percentDisplay = OnscreenText(text = "%s %s" % (self.momPercent, "%"), fg=(0,1,1,1), pos=(-1.05,-.9), scale = .125, font = self.font)
            #print mpos.getX(), " ", mpos.getY()
            self.keys["m1"] = 0

        #Scroll up and down to scroll through weapons
        if self.keys["swap-up"]:
            if self.wepCounter < 2:
                self.wepCounter += 1
            else:
                self.wepCounter = 0
            self.wepDisplay.remove()
            self.wepDisplay = OnscreenText(text = "%s" % (self.wepAmmo[self.wepCounter]), fg = (0,1,1,1), pos = (1, -.9), scale = .125, font = self.font)
            self.wepIcon.remove()
            self.wepIcon = loadObject("Sprites/weapon%s" %(self.wepCounter))
            self.keys["swap-up"] = 0
        if self.keys["swap-down"]:
            if self.wepCounter > 0:
                self.wepCounter -= 1
            else:
                self.wepCounter = 2
            self.wepDisplay.remove()
            self.wepDisplay = OnscreenText(text = "%s" % (self.wepAmmo[self.wepCounter]), fg = (0,1,1,1), pos = (1, -.9), scale = .125, font = self.font)
            self.wepIcon.remove()
            self.wepIcon = loadObject("Sprites/weapon%s" %(self.wepCounter))
            self.keys["swap-down"] = 0

        return Task.cont
    
o = Overlay()
run()